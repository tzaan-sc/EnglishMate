BEGIN TRANSACTION;
CREATE TABLE audit_log (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	action VARCHAR(100) NOT NULL, 
	target_type VARCHAR(50), 
	target_id VARCHAR(50), 
	details TEXT, 
	ip_address VARCHAR(45), 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id) ON DELETE SET NULL
);
CREATE TABLE badge (
	id INTEGER NOT NULL, 
	code VARCHAR(50) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	description VARCHAR(255) NOT NULL, 
	icon VARCHAR(50) NOT NULL, 
	category VARCHAR(50) NOT NULL, 
	xp_reward INTEGER NOT NULL, 
	req_type VARCHAR(50) NOT NULL, 
	req_value INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE challenge (
	id INTEGER NOT NULL, 
	code VARCHAR(50) NOT NULL, 
	title VARCHAR(150) NOT NULL, 
	description VARCHAR(255) NOT NULL, 
	icon VARCHAR(50) NOT NULL, 
	action_type VARCHAR(50) NOT NULL, 
	target INTEGER NOT NULL, 
	xp_reward INTEGER NOT NULL, 
	period VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE daily_activity (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	activity_date DATE NOT NULL, 
	completed_lessons INTEGER NOT NULL, 
	goal_completed BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id, activity_date), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE database_backup (
	id INTEGER NOT NULL, 
	filename VARCHAR(255) NOT NULL, 
	file_path VARCHAR(500) NOT NULL, 
	file_size_bytes BIGINT NOT NULL, 
	backup_type VARCHAR(50) NOT NULL, 
	db_type VARCHAR(50) NOT NULL, 
	is_compressed BOOLEAN NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	notes VARCHAR(255), 
	created_by_id INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(created_by_id) REFERENCES user (id) ON DELETE SET NULL
);
CREATE TABLE email_change_history (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	old_email VARCHAR(120) NOT NULL, 
	new_email VARCHAR(120) NOT NULL, 
	ip_address VARCHAR(45), 
	user_agent VARCHAR(255), 
	changed_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE exam (
	id INTEGER NOT NULL, 
	category VARCHAR(50) NOT NULL, 
	title VARCHAR(255) NOT NULL, 
	duration INTEGER NOT NULL, 
	duration_minutes INTEGER NOT NULL, 
	difficulty VARCHAR(20) NOT NULL, 
	question_bank VARCHAR(80) NOT NULL, 
	selection_type VARCHAR(20) NOT NULL, 
	selected_question_ids TEXT, 
	part_distribution JSON, 
	question_count INTEGER NOT NULL, 
	is_published BOOLEAN NOT NULL, 
	is_active BOOLEAN, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE exam_answer_detail (
	id INTEGER NOT NULL, 
	submission_id INTEGER NOT NULL, 
	question_id INTEGER NOT NULL, 
	user_response JSON, 
	is_correct BOOLEAN, 
	score FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(submission_id) REFERENCES exam_submission (id), 
	FOREIGN KEY(question_id) REFERENCES exam_question (id)
);
CREATE TABLE exam_question (
	id INTEGER NOT NULL, 
	exam_id INTEGER NOT NULL, 
	skill VARCHAR(50), 
	part VARCHAR(50), 
	type VARCHAR(50) NOT NULL, 
	question_text TEXT, 
	option_a VARCHAR(255), 
	option_b VARCHAR(255), 
	option_c VARCHAR(255), 
	option_d VARCHAR(255), 
	correct_answer VARCHAR(255), 
	media_info JSON, 
	transcript TEXT, 
	explanation TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(exam_id) REFERENCES exam (id)
);
CREATE TABLE exam_submission (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	exam_id INTEGER NOT NULL, 
	total_score FLOAT NOT NULL, 
	status VARCHAR(50) NOT NULL, 
	created_at DATETIME NOT NULL, 
	completed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(exam_id) REFERENCES exam (id)
);
CREATE TABLE flashcard_item (
	id INTEGER NOT NULL, 
	set_id INTEGER NOT NULL, 
	term VARCHAR(500) NOT NULL, 
	definition TEXT NOT NULL, 
	image_url VARCHAR(500), 
	"order" INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(set_id) REFERENCES flashcard_set (id)
);
CREATE TABLE flashcard_progress (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	item_id INTEGER NOT NULL, 
	is_known BOOLEAN NOT NULL, 
	review_count INTEGER NOT NULL, 
	srs_level INTEGER NOT NULL, 
	last_reviewed_at DATETIME NOT NULL, 
	next_review_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (user_id, item_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(item_id) REFERENCES flashcard_item (id)
);
CREATE TABLE flashcard_set (
	id INTEGER NOT NULL, 
	title VARCHAR(200) NOT NULL, 
	description TEXT, 
	is_public BOOLEAN NOT NULL, 
	share_code VARCHAR(32), 
	user_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE game_session (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	session_id VARCHAR(64) NOT NULL, 
	game_type VARCHAR(50) NOT NULL, 
	total_questions INTEGER NOT NULL, 
	correct_answers INTEGER NOT NULL, 
	accuracy_rate FLOAT NOT NULL, 
	duration_seconds INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	UNIQUE (session_id)
);
CREATE TABLE grammar_error_log (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	question_id INTEGER NOT NULL, 
	attempt_id INTEGER, 
	user_answer VARCHAR(1) NOT NULL, 
	correct_answer VARCHAR(1) NOT NULL, 
	is_resolved BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(question_id) REFERENCES question (id), 
	FOREIGN KEY(attempt_id) REFERENCES grammar_exercise_attempt (id)
);
CREATE TABLE grammar_exercise_attempt (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	topic_id INTEGER, 
	difficulty VARCHAR(20) NOT NULL, 
	question_count INTEGER NOT NULL, 
	score INTEGER NOT NULL, 
	total_questions INTEGER NOT NULL, 
	duration_seconds INTEGER NOT NULL, 
	completed_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(topic_id) REFERENCES grammar_topic (id)
);
CREATE TABLE grammar_progress (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	topic_id INTEGER NOT NULL, 
	is_completed BOOLEAN NOT NULL, 
	is_favorite BOOLEAN NOT NULL, 
	completed_at DATETIME, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_grammar_topic UNIQUE (user_id, topic_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(topic_id) REFERENCES grammar_topic (id)
);
CREATE TABLE grammar_rule (
	id INTEGER NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	category VARCHAR(80) NOT NULL, 
	summary VARCHAR(280) NOT NULL, 
	explanation TEXT NOT NULL, 
	examples TEXT NOT NULL, 
	exceptions TEXT, 
	common_errors TEXT, 
	quick_table_html TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE grammar_rule_bookmark (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	rule_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_grammar_rule_bookmark UNIQUE (user_id, rule_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(rule_id) REFERENCES grammar_rule (id)
);
CREATE TABLE grammar_topic (
	id INTEGER NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	category VARCHAR(80) NOT NULL, 
	level VARCHAR(2) NOT NULL, 
	difficulty VARCHAR(20) NOT NULL, 
	summary VARCHAR(280) NOT NULL, 
	rule_explanation TEXT NOT NULL, 
	examples_json TEXT NOT NULL, 
	common_mistakes TEXT, 
	tips_tricks TEXT, 
	related_topic_ids VARCHAR(100), 
	order_index INTEGER NOT NULL, 
	exam_targets VARCHAR(160), 
	toeic_parts VARCHAR(80), 
	toeic_weight VARCHAR(20), 
	importance VARCHAR(20), 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE ielts_speaking_answer (
	id INTEGER NOT NULL, 
	submission_id INTEGER NOT NULL, 
	topic_id INTEGER, 
	part INTEGER NOT NULL, 
	question_index INTEGER NOT NULL, 
	question_text TEXT, 
	candidate_transcript TEXT, 
	audio_data_url TEXT, 
	candidate_notes TEXT, 
	ai_feedback TEXT, 
	score FLOAT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(submission_id) REFERENCES ielts_speaking_submission (id), 
	FOREIGN KEY(topic_id) REFERENCES ielts_speaking_topic (id)
);
CREATE TABLE ielts_speaking_submission (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	test_id INTEGER NOT NULL, 
	overall_band FLOAT NOT NULL, 
	fluency_score FLOAT NOT NULL, 
	lexical_score FLOAT NOT NULL, 
	grammar_score FLOAT NOT NULL, 
	pronunciation_score FLOAT NOT NULL, 
	examiner_feedback TEXT, 
	detailed_analysis JSON, 
	status VARCHAR(50) NOT NULL, 
	time_spent INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	completed_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(test_id) REFERENCES ielts_speaking_test (id)
);
CREATE TABLE ielts_speaking_test (
	id INTEGER NOT NULL, 
	title VARCHAR(255) NOT NULL, 
	description TEXT, 
	target_band VARCHAR(20) NOT NULL, 
	difficulty VARCHAR(20) NOT NULL, 
	duration_minutes INTEGER NOT NULL, 
	is_published BOOLEAN NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE ielts_speaking_topic (
	id INTEGER NOT NULL, 
	test_id INTEGER NOT NULL, 
	part INTEGER NOT NULL, 
	topic_title VARCHAR(255) NOT NULL, 
	cue_card_prompt TEXT, 
	questions JSON, 
	prep_time_seconds INTEGER NOT NULL, 
	response_time_seconds INTEGER NOT NULL, 
	"order" INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_id) REFERENCES ielts_speaking_test (id)
);
CREATE TABLE import_history (
	id INTEGER NOT NULL, 
	admin_id INTEGER, 
	filename VARCHAR(255) NOT NULL, 
	file_type VARCHAR(50) NOT NULL, 
	success_count INTEGER NOT NULL, 
	error_count INTEGER NOT NULL, 
	error_log TEXT, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(admin_id) REFERENCES user (id) ON DELETE SET NULL
);
CREATE TABLE lesson (
	id INTEGER NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	level VARCHAR(2) NOT NULL, 
	skill VARCHAR(30) NOT NULL, 
	short_description VARCHAR(280) NOT NULL, 
	content TEXT NOT NULL, 
	examples TEXT NOT NULL, 
	thumbnail_url VARCHAR(255), 
	audio_url VARCHAR(255), 
	audio_url_uk VARCHAR(255), 
	view_count INTEGER NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	skill_data JSON, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "lesson" VALUES(1,'Test lesson','A1','Grammar','A useful lesson','Test content','This is an example.',NULL,NULL,NULL,0,1,'{}','2026-10-05 10:59:16.853902','2026-10-05 10:59:16.853902');
CREATE TABLE lesson_bookmark (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	section_index INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_lesson_bookmark UNIQUE (user_id, lesson_id, section_index), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE lesson_draft (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	draft_type VARCHAR(30) NOT NULL, 
	content TEXT, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_lesson_draft_type UNIQUE (user_id, lesson_id, draft_type), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE lesson_favorite (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_lesson_favorite UNIQUE (user_id, lesson_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE lesson_note (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	content TEXT NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_lesson_note UNIQUE (user_id, lesson_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE lesson_progress (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	completed_at DATETIME NOT NULL, 
	duration_seconds INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id, lesson_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE lesson_rating (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	rating INTEGER NOT NULL, 
	review_text TEXT, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_lesson_rating UNIQUE (user_id, lesson_id), 
	CONSTRAINT ck_lesson_rating_range CHECK (rating >= 1 AND rating <= 5), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE lesson_report (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	reason VARCHAR(100) NOT NULL, 
	details TEXT, 
	status VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE TABLE permission (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	description VARCHAR(255), 
	category VARCHAR(50) NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE question (
	id INTEGER NOT NULL, 
	question_text VARCHAR(500) NOT NULL, 
	option_a VARCHAR(200) NOT NULL, 
	option_b VARCHAR(200) NOT NULL, 
	option_c VARCHAR(200) NOT NULL, 
	option_d VARCHAR(200) NOT NULL, 
	correct_option VARCHAR(1) NOT NULL, 
	explanation VARCHAR(500) NOT NULL, 
	level VARCHAR(2) NOT NULL, 
	topic VARCHAR(80) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "question" VALUES(1,'Question 0','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(2,'Question 1','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(3,'Question 2','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(4,'Question 3','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(5,'Question 4','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(6,'Question 5','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(7,'Question 6','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(8,'Question 7','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(9,'Question 8','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
INSERT INTO "question" VALUES(10,'Question 9','Correct','Wrong B','Wrong C','Wrong D','A','A is correct.','A1','Daily Life','2026-10-05 10:59:16.855947');
CREATE TABLE quiz (
	id INTEGER NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	category VARCHAR(80) NOT NULL, 
	level VARCHAR(2) NOT NULL, 
	skill VARCHAR(30) NOT NULL, 
	difficulty VARCHAR(20) NOT NULL, 
	description VARCHAR(280) NOT NULL, 
	question_count INTEGER NOT NULL, 
	duration_minutes INTEGER NOT NULL, 
	view_count INTEGER NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE quiz_attempt (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	level VARCHAR(2) NOT NULL, 
	topic VARCHAR(80) NOT NULL, 
	score INTEGER NOT NULL, 
	total_questions INTEGER NOT NULL, 
	duration_seconds INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE quiz_attempt_answer (
	id INTEGER NOT NULL, 
	attempt_id INTEGER NOT NULL, 
	question_id INTEGER NOT NULL, 
	selected_option VARCHAR(1), 
	is_correct BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(attempt_id) REFERENCES quiz_attempt (id), 
	FOREIGN KEY(question_id) REFERENCES question (id)
);
CREATE TABLE reading_annotation (
	id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	selected_text TEXT NOT NULL, 
	note_content TEXT, 
	paragraph_index INTEGER, 
	start_offset INTEGER, 
	end_offset INTEGER, 
	color VARCHAR(20), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE role (
	id INTEGER NOT NULL, 
	name VARCHAR(50) NOT NULL, 
	description VARCHAR(255), 
	is_custom BOOLEAN NOT NULL, 
	parent_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(parent_id) REFERENCES role (id) ON DELETE SET NULL
);
CREATE TABLE role_permission (
	id INTEGER NOT NULL, 
	role_id INTEGER NOT NULL, 
	permission_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (role_id, permission_id), 
	FOREIGN KEY(role_id) REFERENCES role (id) ON DELETE CASCADE, 
	FOREIGN KEY(permission_id) REFERENCES permission (id) ON DELETE CASCADE
);
CREATE TABLE system_config (
	id INTEGER NOT NULL, 
	"key" VARCHAR(100) NOT NULL, 
	value TEXT, 
	description VARCHAR(255), 
	is_active BOOLEAN NOT NULL, 
	category VARCHAR(50) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE system_setting (
	id INTEGER NOT NULL, 
	"key" VARCHAR(100) NOT NULL, 
	value TEXT, 
	description VARCHAR(255), 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE toeic_attempt (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	test_id INTEGER NOT NULL, 
	score INTEGER NOT NULL, 
	total_questions INTEGER NOT NULL, 
	time_spent INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	completed_at DATETIME, 
	is_submitted BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(test_id) REFERENCES toeic_test (id)
);
CREATE TABLE toeic_attempt_answer (
	id INTEGER NOT NULL, 
	attempt_id INTEGER NOT NULL, 
	question_id INTEGER NOT NULL, 
	selected_option VARCHAR(1), 
	is_correct BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(attempt_id) REFERENCES toeic_attempt (id), 
	FOREIGN KEY(question_id) REFERENCES toeic_question (id)
);
CREATE TABLE toeic_passage (
	id INTEGER NOT NULL, 
	test_id INTEGER NOT NULL, 
	part INTEGER NOT NULL, 
	passage_text TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_id) REFERENCES toeic_test (id)
);
CREATE TABLE toeic_question (
	id INTEGER NOT NULL, 
	test_id INTEGER NOT NULL, 
	passage_id INTEGER, 
	part INTEGER NOT NULL, 
	question_number INTEGER NOT NULL, 
	question_text VARCHAR(500), 
	option_a VARCHAR(200) NOT NULL, 
	option_b VARCHAR(200) NOT NULL, 
	option_c VARCHAR(200) NOT NULL, 
	option_d VARCHAR(200) NOT NULL, 
	correct_option VARCHAR(1) NOT NULL, 
	explanation TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_id) REFERENCES toeic_test (id), 
	FOREIGN KEY(passage_id) REFERENCES toeic_passage (id)
);
CREATE TABLE toeic_test (
	id INTEGER NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE user (
	id INTEGER NOT NULL, 
	username VARCHAR(40) NOT NULL, 
	email VARCHAR(120) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	role VARCHAR(10) NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	is_email_verified BOOLEAN NOT NULL, 
	email_verification_code VARCHAR(6), 
	email_verification_expiry DATETIME, 
	oauth_provider VARCHAR(20), 
	oauth_id VARCHAR(100), 
	failed_login_attempts INTEGER NOT NULL, 
	lockout_until DATETIME, 
	last_login_at DATETIME, 
	reset_token VARCHAR(100), 
	reset_token_expiry DATETIME, 
	full_name VARCHAR(100), 
	avatar VARCHAR(255), 
	pending_email VARCHAR(120), 
	pending_email_otp VARCHAR(6), 
	pending_email_expiry DATETIME, 
	current_streak INTEGER NOT NULL, 
	longest_streak INTEGER NOT NULL, 
	streak_freeze_count INTEGER NOT NULL, 
	last_activity_date DATE, 
	daily_vocab_goal INTEGER NOT NULL, 
	vocab_review_priority VARCHAR(20) NOT NULL, 
	vocab_auto_play_audio BOOLEAN NOT NULL, 
	vocab_accent VARCHAR(10) NOT NULL, 
	vocab_display_mode VARCHAR(20) NOT NULL, 
	vocab_review_time VARCHAR(20) NOT NULL, 
	vocab_srs_algorithm VARCHAR(20) NOT NULL, 
	vocab_notify_review_due BOOLEAN NOT NULL, 
	vocab_reminder_enabled BOOLEAN NOT NULL, 
	vocab_reminder_time VARCHAR(10) NOT NULL, 
	vocab_push_subscription TEXT, 
	exam_default_type VARCHAR(50) NOT NULL, 
	exam_default_time_limit INTEGER NOT NULL, 
	exam_show_timer BOOLEAN NOT NULL, 
	exam_allow_pause BOOLEAN NOT NULL, 
	exam_show_realtime_score BOOLEAN NOT NULL, 
	exam_auto_submit BOOLEAN NOT NULL, 
	exam_sound_effects BOOLEAN NOT NULL, 
	xp INTEGER NOT NULL, 
	level INTEGER NOT NULL, 
	level_start_date DATE, 
	daily_goal_xp INTEGER NOT NULL, 
	daily_reward_claimed_date DATE, 
	daily_goal_reminder_enabled BOOLEAN NOT NULL, 
	daily_goal_reminder_time VARCHAR(10) NOT NULL, 
	daily_goal_reminder_email BOOLEAN NOT NULL, 
	daily_goal_reminder_popup BOOLEAN NOT NULL, 
	last_daily_goal_reminder_date DATE, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "user" VALUES(1,'admin','admin@test.com','scrypt:32768:8:1$3PpUEHrBZxBDCuUW$3a20dbd7a37145aed464bac185a748e609e652cb51ff083091c021bc624ca99fb43f23130a8da8098aa0d6a0a69c548bedde354c21e8ee866cd9fcd30bebc5a4','ADMIN',1,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'default_avatar.png',NULL,NULL,NULL,0,0,0,NULL,20,'due_date',1,'en-US','flashcard','anytime','standard',1,1,'09:00',NULL,'TOEIC',120,1,1,0,1,1,0,1,NULL,50,NULL,1,'20:00',1,1,NULL,'2026-10-05 10:59:16.850345','2026-10-05 10:59:16.850345');
INSERT INTO "user" VALUES(2,'student','student@test.com','scrypt:32768:8:1$gRFSlEdfw5LFNfsH$24e1886c4be089b5e13a758dbe9d7ba115bc6f6ffcf8649a33265418b303e3f0e71ce4a925f0c88b29bdb2403838c13a7f13e3bb2de409f28c72c637cdd06fbf','USER',1,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'default_avatar.png',NULL,NULL,NULL,0,0,0,NULL,20,'due_date',1,'en-US','flashcard','anytime','standard',1,1,'09:00',NULL,'TOEIC',120,1,1,0,1,1,0,1,NULL,50,NULL,1,'20:00',1,1,NULL,'2026-10-05 10:59:16.852369','2026-10-05 10:59:16.852369');
INSERT INTO "user" VALUES(3,'blocked','blocked@test.com','scrypt:32768:8:1$NfRamKmsqDaMIDCU$08eea4fd3201f43ca4c59f77ee3f6a3f4474f60dfd199a8819ecb86414596a58ec33e716415d53e762bc6b501cac6665ed6e4949a3d6dddb78fe1b42c1a85240','USER',0,0,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'default_avatar.png',NULL,NULL,NULL,0,0,0,NULL,20,'due_date',1,'en-US','flashcard','anytime','standard',1,1,'09:00',NULL,'TOEIC',120,1,1,0,1,1,0,1,NULL,50,NULL,1,'20:00',1,1,NULL,'2026-10-05 10:59:16.853902','2026-10-05 10:59:16.853902');
CREATE TABLE user_badge (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	badge_id INTEGER NOT NULL, 
	unlocked_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_badge UNIQUE (user_id, badge_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(badge_id) REFERENCES badge (id)
);
CREATE TABLE user_challenge (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	challenge_id INTEGER NOT NULL, 
	current_progress INTEGER NOT NULL, 
	is_completed BOOLEAN NOT NULL, 
	is_claimed BOOLEAN NOT NULL, 
	period_date DATE NOT NULL, 
	completed_at DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_challenge_period UNIQUE (user_id, challenge_id, period_date), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(challenge_id) REFERENCES challenge (id)
);
CREATE TABLE user_role (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	role_id INTEGER NOT NULL, 
	expires_at DATETIME, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id, role_id), 
	FOREIGN KEY(user_id) REFERENCES user (id) ON DELETE CASCADE, 
	FOREIGN KEY(role_id) REFERENCES role (id) ON DELETE CASCADE
);
CREATE TABLE user_session (
	id VARCHAR(64) NOT NULL, 
	user_id INTEGER NOT NULL, 
	ip_address VARCHAR(45), 
	user_agent VARCHAR(255), 
	device_info VARCHAR(100), 
	last_activity DATETIME NOT NULL, 
	created_at DATETIME NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id)
);
CREATE TABLE vocabulary (
	id INTEGER NOT NULL, 
	word VARCHAR(100) NOT NULL, 
	pronunciation VARCHAR(100) NOT NULL, 
	part_of_speech VARCHAR(30) NOT NULL, 
	meaning_vi VARCHAR(200) NOT NULL, 
	example_en VARCHAR(300) NOT NULL, 
	example_vi VARCHAR(300) NOT NULL, 
	category VARCHAR(50) NOT NULL, 
	subcategory VARCHAR(100), 
	lesson_unit VARCHAR(100), 
	topic VARCHAR(80) NOT NULL, 
	level VARCHAR(10) NOT NULL, 
	image_url VARCHAR(255), 
	collocations VARCHAR(300), 
	synonyms VARCHAR(200), 
	antonyms VARCHAR(200), 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "vocabulary" VALUES(1,'hello','/həˈləʊ/','interjection','xin chào','Hello, Mai!','Xin chào Mai!','CEFR',NULL,NULL,'Daily Life','A1',NULL,NULL,NULL,NULL,'2026-10-05 10:59:16.856935','2026-10-05 10:59:16.856935');
CREATE TABLE vocabulary_progress (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	vocabulary_id INTEGER NOT NULL, 
	learned_count INTEGER NOT NULL, 
	review_count INTEGER NOT NULL, 
	srs_level INTEGER NOT NULL, 
	is_favorite BOOLEAN NOT NULL, 
	is_skipped BOOLEAN NOT NULL, 
	last_reviewed_at DATETIME NOT NULL, 
	next_review_at DATETIME, 
	personal_notes TEXT, 
	custom_example TEXT, 
	PRIMARY KEY (id), 
	UNIQUE (user_id, vocabulary_id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(vocabulary_id) REFERENCES vocabulary (id)
);
CREATE TABLE word_report (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	vocabulary_id INTEGER NOT NULL, 
	reason VARCHAR(255) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(vocabulary_id) REFERENCES vocabulary (id)
);
CREATE TABLE writing_submission (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	lesson_id INTEGER NOT NULL, 
	content TEXT NOT NULL, 
	word_count INTEGER NOT NULL, 
	score FLOAT NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	feedback TEXT, 
	evaluation_data JSON, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES user (id), 
	FOREIGN KEY(lesson_id) REFERENCES lesson (id)
);
CREATE INDEX ix_lesson_rating_user_id ON lesson_rating (user_id);
CREATE INDEX ix_lesson_rating_lesson_id ON lesson_rating (lesson_id);
CREATE UNIQUE INDEX ix_system_setting_key ON system_setting ("key");
CREATE UNIQUE INDEX ix_system_config_key ON system_config ("key");
CREATE INDEX ix_database_backup_created_by_id ON database_backup (created_by_id);
CREATE INDEX ix_database_backup_backup_type ON database_backup (backup_type);
CREATE UNIQUE INDEX ix_database_backup_filename ON database_backup (filename);
CREATE INDEX ix_database_backup_created_at ON database_backup (created_at);
CREATE UNIQUE INDEX ix_user_username ON user (username);
CREATE UNIQUE INDEX ix_user_email ON user (email);
CREATE INDEX ix_exam_category ON exam (category);
CREATE INDEX ix_lesson_level ON lesson (level);
CREATE INDEX ix_lesson_skill ON lesson (skill);
CREATE INDEX ix_vocabulary_level ON vocabulary (level);
CREATE INDEX ix_vocabulary_lesson_unit ON vocabulary (lesson_unit);
CREATE INDEX ix_vocabulary_category ON vocabulary (category);
CREATE INDEX ix_vocabulary_topic ON vocabulary (topic);
CREATE INDEX ix_vocabulary_word ON vocabulary (word);
CREATE INDEX ix_vocabulary_subcategory ON vocabulary (subcategory);
CREATE INDEX ix_question_level ON question (level);
CREATE INDEX ix_question_topic ON question (topic);
CREATE INDEX ix_grammar_topic_category ON grammar_topic (category);
CREATE INDEX ix_grammar_topic_level ON grammar_topic (level);
CREATE INDEX ix_grammar_topic_order_index ON grammar_topic (order_index);
CREATE INDEX ix_grammar_rule_category ON grammar_rule (category);
CREATE INDEX ix_quiz_level ON quiz (level);
CREATE INDEX ix_quiz_skill ON quiz (skill);
CREATE INDEX ix_quiz_category ON quiz (category);
CREATE INDEX ix_quiz_difficulty ON quiz (difficulty);
CREATE UNIQUE INDEX ix_badge_code ON badge (code);
CREATE UNIQUE INDEX ix_challenge_code ON challenge (code);
CREATE UNIQUE INDEX ix_permission_name ON permission (name);
CREATE UNIQUE INDEX ix_role_name ON role (name);
CREATE INDEX ix_daily_activity_user_id ON daily_activity (user_id);
CREATE INDEX ix_daily_activity_activity_date ON daily_activity (activity_date);
CREATE INDEX ix_user_session_user_id ON user_session (user_id);
CREATE INDEX ix_email_change_history_user_id ON email_change_history (user_id);
CREATE INDEX ix_toeic_passage_test_id ON toeic_passage (test_id);
CREATE INDEX ix_toeic_attempt_user_id ON toeic_attempt (user_id);
CREATE INDEX ix_toeic_attempt_test_id ON toeic_attempt (test_id);
CREATE INDEX idx_toeic_attempt_user_created ON toeic_attempt (user_id, created_at);
CREATE INDEX ix_exam_question_skill ON exam_question (skill);
CREATE INDEX ix_exam_question_exam_id ON exam_question (exam_id);
CREATE INDEX ix_exam_submission_user_id ON exam_submission (user_id);
CREATE INDEX idx_exam_sub_user_created ON exam_submission (user_id, created_at);
CREATE INDEX ix_exam_submission_exam_id ON exam_submission (exam_id);
CREATE INDEX ix_ielts_speaking_topic_part ON ielts_speaking_topic (part);
CREATE INDEX ix_ielts_speaking_topic_test_id ON ielts_speaking_topic (test_id);
CREATE INDEX ix_ielts_speaking_submission_user_id ON ielts_speaking_submission (user_id);
CREATE INDEX idx_ielts_speaking_sub_user_created ON ielts_speaking_submission (user_id, created_at);
CREATE INDEX ix_ielts_speaking_submission_test_id ON ielts_speaking_submission (test_id);
CREATE INDEX ix_lesson_favorite_user_id ON lesson_favorite (user_id);
CREATE INDEX ix_lesson_favorite_lesson_id ON lesson_favorite (lesson_id);
CREATE INDEX ix_lesson_progress_user_id ON lesson_progress (user_id);
CREATE INDEX ix_lesson_progress_lesson_id ON lesson_progress (lesson_id);
CREATE INDEX ix_vocabulary_progress_vocabulary_id ON vocabulary_progress (vocabulary_id);
CREATE INDEX ix_vocabulary_progress_user_id ON vocabulary_progress (user_id);
CREATE INDEX idx_vocab_prog_srs ON vocabulary_progress (user_id, is_skipped, next_review_at);
CREATE INDEX ix_word_report_vocabulary_id ON word_report (vocabulary_id);
CREATE INDEX ix_word_report_user_id ON word_report (user_id);
CREATE INDEX ix_quiz_attempt_user_id ON quiz_attempt (user_id);
CREATE INDEX idx_quiz_attempt_user_created ON quiz_attempt (user_id, created_at);
CREATE INDEX ix_flashcard_set_user_id ON flashcard_set (user_id);
CREATE UNIQUE INDEX ix_flashcard_set_share_code ON flashcard_set (share_code);
CREATE INDEX ix_game_session_user_id ON game_session (user_id);
CREATE INDEX ix_lesson_note_lesson_id ON lesson_note (lesson_id);
CREATE INDEX ix_lesson_note_user_id ON lesson_note (user_id);
CREATE INDEX ix_lesson_draft_user_id ON lesson_draft (user_id);
CREATE INDEX ix_lesson_draft_lesson_id ON lesson_draft (lesson_id);
CREATE INDEX ix_reading_annotation_user_id ON reading_annotation (user_id);
CREATE INDEX ix_reading_annotation_lesson_id ON reading_annotation (lesson_id);
CREATE INDEX ix_lesson_bookmark_lesson_id ON lesson_bookmark (lesson_id);
CREATE INDEX ix_lesson_bookmark_user_id ON lesson_bookmark (user_id);
CREATE INDEX ix_lesson_report_user_id ON lesson_report (user_id);
CREATE INDEX ix_lesson_report_lesson_id ON lesson_report (lesson_id);
CREATE INDEX ix_grammar_progress_user_id ON grammar_progress (user_id);
CREATE INDEX ix_grammar_progress_topic_id ON grammar_progress (topic_id);
CREATE INDEX ix_grammar_exercise_attempt_user_id ON grammar_exercise_attempt (user_id);
CREATE INDEX ix_grammar_exercise_attempt_topic_id ON grammar_exercise_attempt (topic_id);
CREATE INDEX ix_grammar_rule_bookmark_rule_id ON grammar_rule_bookmark (rule_id);
CREATE INDEX ix_grammar_rule_bookmark_user_id ON grammar_rule_bookmark (user_id);
CREATE INDEX ix_user_badge_user_id ON user_badge (user_id);
CREATE INDEX ix_user_badge_badge_id ON user_badge (badge_id);
CREATE INDEX ix_user_challenge_challenge_id ON user_challenge (challenge_id);
CREATE INDEX ix_user_challenge_period_date ON user_challenge (period_date);
CREATE INDEX ix_user_challenge_user_id ON user_challenge (user_id);
CREATE INDEX ix_writing_submission_user_id ON writing_submission (user_id);
CREATE INDEX ix_writing_submission_lesson_id ON writing_submission (lesson_id);
CREATE INDEX ix_role_permission_permission_id ON role_permission (permission_id);
CREATE INDEX ix_role_permission_role_id ON role_permission (role_id);
CREATE INDEX ix_user_role_role_id ON user_role (role_id);
CREATE INDEX ix_user_role_user_id ON user_role (user_id);
CREATE INDEX ix_audit_log_action ON audit_log (action);
CREATE INDEX ix_audit_log_user_id ON audit_log (user_id);
CREATE INDEX ix_audit_log_created_at ON audit_log (created_at);
CREATE INDEX ix_import_history_file_type ON import_history (file_type);
CREATE INDEX ix_import_history_admin_id ON import_history (admin_id);
CREATE INDEX ix_import_history_created_at ON import_history (created_at);
CREATE INDEX ix_toeic_question_test_id ON toeic_question (test_id);
CREATE INDEX ix_toeic_question_passage_id ON toeic_question (passage_id);
CREATE INDEX ix_exam_answer_detail_submission_id ON exam_answer_detail (submission_id);
CREATE INDEX ix_exam_answer_detail_question_id ON exam_answer_detail (question_id);
CREATE INDEX ix_ielts_speaking_answer_topic_id ON ielts_speaking_answer (topic_id);
CREATE INDEX ix_ielts_speaking_answer_submission_id ON ielts_speaking_answer (submission_id);
CREATE INDEX ix_quiz_attempt_answer_attempt_id ON quiz_attempt_answer (attempt_id);
CREATE INDEX ix_flashcard_item_set_id ON flashcard_item (set_id);
CREATE INDEX ix_grammar_error_log_question_id ON grammar_error_log (question_id);
CREATE INDEX ix_grammar_error_log_attempt_id ON grammar_error_log (attempt_id);
CREATE INDEX ix_grammar_error_log_user_id ON grammar_error_log (user_id);
CREATE INDEX ix_toeic_attempt_answer_attempt_id ON toeic_attempt_answer (attempt_id);
CREATE INDEX ix_toeic_attempt_answer_question_id ON toeic_attempt_answer (question_id);
CREATE INDEX ix_flashcard_progress_item_id ON flashcard_progress (item_id);
CREATE INDEX ix_flashcard_progress_user_id ON flashcard_progress (user_id);
COMMIT;